<?php
//// index.php
//
//// Максимальный размер файлов в байтах (8 ГБ)
////define('MAX_SIZE', 8 * 1024 * 1024 * 1024);
//
//// Папка для загрузки файлов
//$uploadDir = 'upload/';
//
//// Получаем список файлов
//$files = array_diff(scandir($uploadDir), array('.', '..'));
//
//// Функция для получения размера папки
////function getFolderSize($folder) {
////    $size = 0;
////    foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($folder, FilesystemIterator::SKIP_DOTS)) as $file) {
////        $size += $file->getSize();
////    }
////    return $size;
////}
//
//// Проверяем размер папки
////if (getFolderSize($uploadDir) > MAX_SIZE) {
////    die('Превышен максимальный размер хранилища.');
////}
//
//// Обработка загрузки файлов
//if ($_SERVER["REQUEST_METHOD"] === "POST") {
//    if (isset($_FILES["file"])) {
//        $file = $_FILES["file"];
//        $targetFile = $uploadDir . basename($file["name"]);
//        if (move_uploaded_file($file["tmp_name"], $targetFile)) {
//            echo "<script>window.location.href = window.location.href;</script>";
//        } else {
//            echo "Ошибка при загрузке файла.";
//        }
//    } elseif (isset($_POST["file_url"])) {
//        $fileUrl = $_POST["file_url"];
//        $fileName = microtime(true) . ".png";
//        $targetFile = $uploadDir . $fileName;
//
//        $pathInfo = pathinfo($targetFile);
//        if (!isset($pathInfo["extension"])) {
//            $targetFile .= ".png";
//        }
//
//        // Используем cURL для скачивания файла
//        $ch = curl_init($fileUrl);
//        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
//        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
//        $fileContent = curl_exec($ch);
//
//        if ($fileContent === false) {
//            echo "cURL Error: " . curl_error($ch);
//        } else {
//            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
//            if ($httpCode == 200) {
//                if (file_put_contents($targetFile, $fileContent)) {
//                    echo "<script>window.location.href = window.location.href;</script>";
//                } else {
//                    echo "Ошибка при сохранении файла.";
//                }
//            } else {
//                echo "HTTP Error: $httpCode";
//            }
//        }
//
//        curl_close($ch);
//    }
//}
//?>